import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class sis {
	Connection con;
	Statement sql;
	sis() throws Exception
	{
		FileInputStream fis = new FileInputStream("C:\\Users\\Yakesh\\eclipse-workspace\\Student Information System\\src\\sisdb.properties");
		Properties prop = new Properties();
		prop.load(fis);
		con=DriverManager.getConnection(prop.getProperty("url"),prop.getProperty("username"),prop.getProperty("password"));
		sql=con.createStatement();
		con.setAutoCommit(false);
	}
	List<course> availableCourse = new ArrayList<>();
	List<student> availableStudent = new ArrayList<>();
	List<teacher> availableTeacher = new ArrayList<>();
	void enrollStudentInCourse(int id,student Student, course Course) throws Exception
	{
		Student.enrollInCourse(id,Course);	
	}
	void assignTeacherToCourse(teacher Teacher, course Course) throws Exception
	{
		Course.AssignTeacher(Teacher);
		Teacher.courses.add(Course);
	}
	void recordPayment(int id,student Student, double amount, LocalDate date) throws Exception
	{
		payment p = new payment(id,Student.student_id,amount,date);
		Student.payment.add(p);
		p.payments.add(Student);
		PreparedStatement s = con.prepareStatement("insert into payments(student_id,amount,payment_date) values(?,?,?)");
		s.setInt(1, Student.student_id);
		s.setDouble(2,amount);
		s.setDate(3,Date.valueOf(date));
		s.executeUpdate();
		con.commit();
		
	}
	List<enrollment> generateEnrollmentReport(course Course)
	{
		return Course.enrollments;
	}
	List<payment> generatePaymentReport(student Student)
	{
		return Student.payment;
	}
	void  calculateCourseStatistics(course Course)
	{
		System.out.println("Total enrollment : "+Course.enrollments.size());
	}
	List<enrollment> getEnrollmentsForStudent(student Student)
	{
		return Student.enrolledCourses;
	}
	List<course> GetCoursesForTeacher(teacher Teacher)
	{
		return Teacher.courses;
	}
}
