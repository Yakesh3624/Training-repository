import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import exception.InvalidTeacherDataException;

public class Teacher {
	
	Connection con;
	Statement sql; 
	
	int teacher_id;
	String first_name;
	String last_name ;
	String email;
	List<Course> courses = new ArrayList<>();
	Teacher(int id,String fname,String lname,String email) throws Exception
	{
		if(id<=0)
		{
			throw new InvalidTeacherDataException("Invalid Enrollment ID");
		}
		if(fname.length()<3)
		{
			throw new InvalidTeacherDataException("Invalid Enrollment ID");
		}
		teacher_id=id;
		first_name=fname;
		last_name =lname;
		this.email=email;
		FileInputStream fis = new FileInputStream("C:\\Users\\Yakesh\\eclipse-workspace\\Student Information System\\src\\sisdb.properties");
		Properties prop = new Properties();
		prop.load(fis);
		con=DriverManager.getConnection(prop.getProperty("url"),prop.getProperty("username"),prop.getProperty("password"));
		con.setAutoCommit(false);
		sql=con.createStatement();
		PreparedStatement s = con.prepareStatement("insert into teacher(teacher_id,first_name,last_name,email) values(?,?,?,?)");
		s.setInt(1, id);
		s.setString(2,first_name);
		s.setString(3, last_name);
		s.setString(4, email);
		s.executeUpdate();
		con.commit();
	}
	
	void UpdateTeacherInfo(int id,String firstName,String lastName, String email) throws Exception
	{
		if(id<=0)
		{
			throw new InvalidTeacherDataException("Invalid Enrollment ID");
		}
		if(firstName.length()<3)
		{
			throw new InvalidTeacherDataException("Invalid Enrollment ID");
		}
		first_name=firstName;
		last_name=lastName;
		this.email=email;
		PreparedStatement s = con.prepareStatement("update teacher set first_name=?,last_name=?,email=? where teacher_id=?");
		s.setString(1,first_name);
		s.setString(2, last_name);
		s.setString(3, email);
		s.setInt(4, id);
		s.executeUpdate();
		con.commit();
		
	}
	void displayTeacherInfo()
	{
		System.out.println("Teacher ID : "+teacher_id);
		System.out.println("First Name : "+first_name);
		System.out.println("Last Name  : "+last_name);
		System.out.println("Email ID   : "+email);
	}
	List<Course> getAssignedCourses()
	{
		return courses;
	}

}

