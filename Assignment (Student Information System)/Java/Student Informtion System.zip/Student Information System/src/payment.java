import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import exception.InsufficientFundsException;
import exception.PaymentValidationException;

public class payment {
	
	int payment_id; 
	int student_id; 
	double amount; 
	LocalDate payment_date;
	List<student> payments = new ArrayList<>();
	
	payment(int id,int s_id,double amount,LocalDate date) throws Exception
	{
		if(amount<=0)
		{
			throw new InsufficientFundsException();
		}
		if(id<=0)
		{
			throw new PaymentValidationException("Invalid Payment ID");
		}
		if(s_id<=0)
		{
			throw new PaymentValidationException("Invalid Student ID");
		}
		
		payment_id=id; 
		student_id=s_id; 
		this.amount=amount; 
		payment_date=date;
		
	}
	List<student> getStudent()
	{
		return payments;
	}
	double getPaymentAmount()
	{
		return this.amount;
	}
	LocalDate getPaymentDate()
	{
		return this.payment_date;
	}

}
