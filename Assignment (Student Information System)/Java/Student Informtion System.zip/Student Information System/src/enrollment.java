import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import exception.InvalidEnrollmentDataException;

public class enrollment {
	int enrollment_id; 
	int student_id; 
	int course_id; 
	LocalDate enrollment_date; 
	List<student> student = new ArrayList<>();
	List<course> course = new ArrayList<>();
	
	enrollment(int id, int student_id, int course_id,	LocalDate enrollment_date) throws Exception
	{
		if(id<=0)
		{
			throw new InvalidEnrollmentDataException("Invalid Enrollment ID");
		}
		if(student_id<=0)
		{
			throw new InvalidEnrollmentDataException("Invalid Student ID");
		}
		if(course_id<=0)
		{
			throw new InvalidEnrollmentDataException("Invalid Course ID");
		}
		enrollment_id=id; 
		this.student_id=student_id; 
		this.course_id=course_id; 
		this.enrollment_date=enrollment_date;
		
	}
	
	List<student> getStudent()
	{
		return student;
	}
	List<course> getCourse()
	{
		return course;
	}
}
