import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import exception.InvalidCourseDataException;
public class Course {
	Connection con;
	Statement sql; 
	
	int course_id; 
	String course_name; 
	int credits; 
	int teacher_id;
	List<Enrollment> enrollments = new ArrayList<>();
	List<Teacher> teachers = new ArrayList<>();
	
	Course(int id,String name, int credits, int teach_id) throws Exception
	{
		if(id<=0)
		{
			throw new InvalidCourseDataException("Invalid Course ID");
		}
		if(name.length()<3)
		{
			throw new InvalidCourseDataException("Invalid Course name");
		}
		if(credits <0)
		{
			throw new InvalidCourseDataException("Invalid Credits");
		}
		course_id=id;
		course_name=name;
		this.credits=credits;
		teacher_id=teach_id;
		FileInputStream fis = new FileInputStream("C:\\Users\\Yakesh\\eclipse-workspace\\Student Information System\\src\\sisdb.properties");
		Properties prop = new Properties();
		prop.load(fis);
		con=DriverManager.getConnection(prop.getProperty("url"),prop.getProperty("username"),prop.getProperty("password"));
		con.setAutoCommit(false);
		sql=con.createStatement();
		PreparedStatement s = con.prepareStatement("insert into courses(course_id,course_name,credits,teacher_id) values (?,?,?,?)");
		s.setInt(1,id);
		s.setString(2, course_name);
		s.setInt(3, credits);
		if(teacher_id==0)
			s.setString(4, null);
		else
		s.setInt(4, teacher_id);
		s.executeUpdate();
		con.commit();
		
	}
	
	void AssignTeacher(Teacher Teacher) throws Exception
	{
		this.teacher_id=Teacher.teacher_id;
		teachers.add(Teacher);
		Teacher.courses.add(this);
		PreparedStatement s = con.prepareStatement("update courses set teacher_id=? where course_id=?");
		s.setInt(1, this.teacher_id);
		s.setInt(2, this.course_id);
		s.executeUpdate();
		con.commit();
	}
	void UpdateCourseInfo(int id,String courseName,int cred, int t_id ) throws Exception
	{
		if(id<=0)
		{
			throw new InvalidCourseDataException("Invalid Course ID");
		}
		if(courseName.length()<3)
		{
			throw new InvalidCourseDataException("Invalid Course name");
		}
		if(cred <0)
		{
			throw new InvalidCourseDataException("Invalid Credits");
		}
		course_name=courseName;
		credits=cred;
		teacher_id=t_id;
		PreparedStatement s = con.prepareStatement("update courses set course_name=?, credits=?, teacher_id=? where course_id=?");
		s.setString(1, course_name);
		s.setInt(2, credits);
		s.setInt(3, t_id);
		s.setInt(4, id);
		s.executeUpdate();
		con.commit();
	}
	void displayCourseInfo()
	{
		System.out.println("Course ID   : "+course_id);
		System.out.println("Course Name : "+course_name);
		System.out.println("Credits     : "+credits);
		System.out.println("Teacher ID  : "+teacher_id);
	}
	List<Enrollment> getEnrollments()
	{
		return enrollments;
	}
	List<Teacher> getTeacher()
	{
		return teachers;
	}

}
