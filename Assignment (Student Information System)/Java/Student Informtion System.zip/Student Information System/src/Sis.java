import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class Sis {
	Connection con;
	Statement sql;
	Sis() throws Exception
	{
		FileInputStream fis = new FileInputStream("C:\\Users\\Yakesh\\eclipse-workspace\\Student Information System\\src\\sisdb.properties");
		Properties prop = new Properties();
		prop.load(fis);
		con=DriverManager.getConnection(prop.getProperty("url"),prop.getProperty("username"),prop.getProperty("password"));
		sql=con.createStatement();
		con.setAutoCommit(false);
	}
	List<Course> availableCourse = new ArrayList<>();
	List<Student> availableStudent = new ArrayList<>();
	List<Teacher> availableTeacher = new ArrayList<>();
	void enrollStudentInCourse(int id,Student Student, Course Course) throws Exception
	{
		Student.enrollInCourse(id,Course);	
	}
	void assignTeacherToCourse(Teacher Teacher, Course Course) throws Exception
	{
		Course.AssignTeacher(Teacher);
		Teacher.courses.add(Course);
	}
	void recordPayment(int id,Student Student, double amount, LocalDate date) throws Exception
	{
		Payment p = new Payment(id,Student.student_id,amount,date);
		Student.payment.add(p);
		p.payments.add(Student);
		PreparedStatement s = con.prepareStatement("insert into payments(student_id,amount,payment_date) values(?,?,?)");
		s.setInt(1, Student.student_id);
		s.setDouble(2,amount);
		s.setDate(3,Date.valueOf(date));
		s.executeUpdate();
		con.commit();
		
	}
	List<Enrollment> generateEnrollmentReport(Course Course)
	{
		return Course.enrollments;
	}
	List<Payment> generatePaymentReport(Student Student)
	{
		return Student.payment;
	}
	void  calculateCourseStatistics(Course Course)
	{
		System.out.println("Total enrollment : "+Course.enrollments.size());
	}
	List<Enrollment> getEnrollmentsForStudent(Student Student)
	{
		return Student.enrolledCourses;
	}
	List<Course> GetCoursesForTeacher(Teacher Teacher)
	{
		return Teacher.courses;
	}
}
