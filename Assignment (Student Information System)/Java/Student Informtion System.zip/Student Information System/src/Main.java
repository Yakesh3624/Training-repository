import java.time.LocalDate;

public class Main {
	
	public static void main(String []args) throws Exception
	{
		
		Sis sis= new Sis();
		Student s1 = new Student(1,"John","Doe",LocalDate.of(1995, 8, 15),"john.doe@example.com","1234567890");
		
		Course c1 = new Course(100,"Introduction to Programming",3,0);
		Course c2 = new Course(101,"Mathematics",4,0);
		
		s1.enrollInCourse(1,c1);
		sis.enrollStudentInCourse(2,s1, c2);
		
		Course c3 = new Course(302,"Advanced Database Management",4,0);
		Teacher t1 = new Teacher(1,"Sarah","Smith","sarah.smith@example.com");
		c3.AssignTeacher(t1);
		
		sis.recordPayment(1, s1, 500, LocalDate.of(2003,4,10));
		
		for(Enrollment e:c1.getEnrollments())
		{
			System.out.println(e.student_id);
		}
		
	}

}






//public class Main {
//	
//	public static void main(String []args) throws Exception
//	{
//		
//		sis sis= new sis();
//        student s1 = new student(1, "John", "Doe", LocalDate.of(2000,05,15), "john.doe@example.com", "1234567890");
//        teacher t1 = new teacher(1, "Smith", "Johnson", "smith.johnson@example.com");
//        course c1 = new course(1, "Computer Science", 3,1);
//         
//        sis.availableStudent.add(s1);
//        sis.availableCourse.add(c1);
//        sis.availableTeacher.add(t1);
//        
//        sis.enrollStudentInCourse(s1, c1);
//        sis.assignTeacherToCourse(t1, c1);
//        sis.recordPayment(s1, 500,LocalDate.now());
//         
//        s1.displayStudentInfo();
//		Scanner sc = new Scanner(System.in);
//		while(true)
//		{
//			System.out.println("1.Create Student "
//					+ "\n2.Enroll in a Course "
//					+ "\n3.Update Student Info "
//					+ "\n4.Make Payment "
//					+ "\n5.Create Course "
//					+ "\n6. Assign Teacher "
//					+ "\n7.Update Course Info "
//					+ "\n8.Create Teacher "
//					+ "\n9.Update Teacher Info "
//					+ "\n10.Exit");
//			int choise = sc.nextInt();
//			if(choise==1)
//			{
//				System.out.println("Student ID : ");
//				int id=sc.nextInt();
//				System.out.println("Student First Name : ");
//				String fname=sc.next();
//				System.out.println("Student Last Name : ");
//				String lname=sc.next();
//				System.out.println("Student Date of Birth(YYYY MM DD) : ");
//				LocalDate dob = LocalDate.of(sc.nextInt(), sc.nextInt(), sc.nextInt());
//				System.out.println("Student Email : ");
//				String email=sc.next();
//				System.out.println("Student Phone Number : ");
//				String phone=sc.next();
//				student s = new student(id,fname,lname,dob,email,phone);
//				sisclass.availableStudent.add(s);
//			}
//			else if(choise==2)
//			{
//				course Course=null;
//				student Student = null;
//				System.out.println("Enter Studnet ID : ");
//				int id = sc.nextInt();
//				System.out.println("Enter Course Name : ");
//				String name = sc.next();
//				for(course c:sisclass.availableCourse)
//				{
//					if(c.course_name.equals(name))
//					{
//						Course=c;
//						break;
//					}
//					else
//					{
//						throw new CourseNotFoundException();
//					}
//				}
//				for(student s:sisclass.availableStudent)
//				{
//					if(s.student_id==id)
//					{
//						Student=s;
//						break;
//					}
//					else
//					{
//						throw new StudentNotFoundException();
//					}
//				}
//				sisclass.enrollStudentInCourse(Student, Course);
//				
//			}
//			else if(choise==3)
//			{
//				System.out.println("Student ID : ");
//				int id=sc.nextInt();
//				System.out.println("Student First Name : ");
//				String fname=sc.next();
//				System.out.println("Student Last Name : ");
//				String lname=sc.next();
//				System.out.println("Student Date of Birth(YYYY MM DD) : ");
//				LocalDate dob = LocalDate.of(sc.nextInt(), sc.nextInt(), sc.nextInt());
//				System.out.println("Student Email : ");
//				String email=sc.next();
//				System.out.println("Student Phone Number : ");
//				String phone=sc.next();
//				for(student s:sisclass.availableStudent)
//				{
//					if(s.student_id==id)
//					{
//						s.updateStudentInfo(id, fname, lname, dob, email, phone);
//						s.displayStudentInfo();
//					}
//					else
//					{
//						throw new StudentNotFoundException();
//					}
//				}
//			}
//			else if(choise==4)
//			{
//				System.out.println("Enter Student ID : ");
//				int id=sc.nextInt();
//				System.out.println("Enter amount : ");
//				double amount=sc.nextDouble();
//				for(student s:sisclass.availableStudent)
//				{
//					if(s.student_id==id)
//					{
//						sisclass.recordPayment(s, amount, LocalDate.now());
//					}
//				}
//				
//			}
//			else if(choise==5)
//			{
//				System.out.println("Enter Course ID : ");
//				int id =sc.nextInt();
//				System.out.println("Enter Course Name : ");
//				String name=sc.next();
//				System.out.println("Enter Course Credits : ");
//				int cred=sc.nextInt();
//				System.out.println("Enter Teacher ID : ");
//				int tid=sc.nextInt();
//				course c = new course(id,name,cred,tid);
//				sisclass.availableCourse.add(c);
//				
//			}
//			else if(choise==6)
//			{
//				System.out.println("Enter Course ID : ");
//				int cid=sc.nextInt();
//				System.out.println("Enter Teacher ID : ");
//				int tid=sc.nextInt();
//				course Course = null;
//				teacher Teacher = null;
//				
//				for(course c : sisclass.availableCourse)
//				{
//					if(c.course_id==cid)
//					{
//						Course=c;
//						break;
//					}
//					else
//					{
//						throw new CourseNotFoundException();
//					}
//				}
//				for(teacher t : sisclass.availableTeacher)
//				{
//					if(t.teacher_id==tid)
//					{
//						Teacher=t;
//						break;
//					}
//					else
//					{
//						throw new TeacherNotFoundException();
//					}
//				}
//				sisclass.assignTeacherToCourse(Teacher, Course);
//			}
//			else if(choise==7)
//			{
//				System.out.println("Enter Course ID : ");
//				int id =sc.nextInt();
//				System.out.println("Enter Course Name : ");
//				String name=sc.next();
//				System.out.println("Enter Course Credits : ");
//				int cred=sc.nextInt();
//				System.out.println("Enter Teacher ID : ");
//				int tid=sc.nextInt();
//				
//				for(course c:sisclass.availableCourse)
//				{
//					if(c.course_id==id)
//					{
//						c.UpdateCourseInfo(id, name, cred, tid);
//					}
//				}
//			}
//			else if(choise==8)
//			{
//				System.out.println("Enter Teacher ID : ");
//				int id =sc.nextInt();
//				System.out.println("Enter Teacher First Name : ");
//				String fname=sc.next();
//				System.out.println("Enter Teacher Last Name : ");
//				String lname=sc.next();
//				System.out.println("Enter Teacher Email : ");
//				String email=sc.next();
//				teacher t= new teacher(id,fname,lname,email);
//				sisclass.availableTeacher.add(t);
//				
//			}
//			else if(choise==9)
//			{
//				System.out.println("Enter Teacher ID : ");
//				int id =sc.nextInt();
//				System.out.println("Enter Teacher First Name : ");
//				String fname=sc.next();
//				System.out.println("Enter Teacher Last Name : ");
//				String lname=sc.next();
//				System.out.println("Enter Teacher Email : ");
//				String email=sc.next();
//				for(teacher t : sisclass.availableTeacher)
//				{
//					if(t.teacher_id==id)
//					{
//						t.UpdateTeacherInfo(id, fname, lname, email);
//						break;
//					}
//					else
//					{
//						throw new TeacherNotFoundException();
//					}
//				}
//				
//			}
//			else if(choise==10)
//			{
//				break;
//			}
//			else
//			{
//				break;
//			}
//			
//		}
	
//		sc.close();
//	}
//
//}
