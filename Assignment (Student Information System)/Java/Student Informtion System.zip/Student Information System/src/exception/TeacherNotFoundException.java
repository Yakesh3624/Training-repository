package exception;

public class TeacherNotFoundException extends Exception {

	public TeacherNotFoundException() {
		super("Teacher not found");
	}

}
