package exception;

public class InvalidStudentDataException extends Exception {

	public InvalidStudentDataException(String m) {
		super(m);
	}

}
