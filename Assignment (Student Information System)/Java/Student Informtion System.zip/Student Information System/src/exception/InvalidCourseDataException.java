package exception;

public class InvalidCourseDataException extends Exception{

	public InvalidCourseDataException(String m) {
		super(m);
	}

}
