package exception;

public class PaymentValidationException extends Exception {

	public PaymentValidationException(String m) {
		super(m);
	}


}
