package exception;

public class InvalidTeacherDataException extends Exception {

	public InvalidTeacherDataException(String m) {
		super(m);
	}

}
