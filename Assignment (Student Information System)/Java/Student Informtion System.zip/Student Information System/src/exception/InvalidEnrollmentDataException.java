package exception;

public class InvalidEnrollmentDataException extends Exception{

	public InvalidEnrollmentDataException(String m) {
		super(m);
	}

}
