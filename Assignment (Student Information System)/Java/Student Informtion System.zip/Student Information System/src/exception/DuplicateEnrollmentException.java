package exception;

public class DuplicateEnrollmentException extends Exception {

	public DuplicateEnrollmentException() {
		super("You have already enrolled in this Course");
	}

}
