import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import exception.DuplicateEnrollmentException;
import exception.InsufficientFundsException;
import exception.InvalidStudentDataException;
import exception.PaymentValidationException;

public class Student{
	Connection con;
	Statement sql; 
	int student_id;
	String first_name;
	String last_name; 
	LocalDate date_of_birth; 
	String email;
	String phone_number;
	List<Enrollment> enrolledCourses = new ArrayList<>(); 
	List<Payment>  payment = new ArrayList<>();
	
	Student(int id,String firstName, String lastName, LocalDate dob,String email, String phone) throws Exception
	{
		if(id<=0)
		{
			throw new InvalidStudentDataException("Student ID must be positive");
		}
		if(phone.length()!=10)
		{
			throw new InvalidStudentDataException("Invalid Phone number");
		}
		if(firstName.length()<3)
		{
			throw new InvalidStudentDataException("Invalid First name");
		}
		student_id=id;
		first_name=firstName;
		last_name=lastName;
		date_of_birth=dob;
		this.email=email;
		phone_number=phone;
		FileInputStream fis = new FileInputStream("C:\\Users\\Yakesh\\eclipse-workspace\\Student Information System\\src\\sisdb.properties");
		Properties prop = new Properties();
		prop.load(fis);
		con=DriverManager.getConnection(prop.getProperty("url"),prop.getProperty("username"),prop.getProperty("password"));
		con.setAutoCommit(false);
		sql=con.createStatement();
		PreparedStatement s = con.prepareStatement("insert into students(student_id,first_name,last_name,date_of_birth,email,phone_number) values (?,?,?,?,?,?)");
		s.setInt(1, id);
		s.setString(2,first_name);
		s.setString(3,last_name);
		s.setDate(4,Date.valueOf(date_of_birth));
		s.setString(5,email);
		s.setString(6,phone_number);
		s.executeUpdate();
		con.commit();
		
	}
	
	void enrollInCourse(int id,Course Course) throws Exception
	{
		for(Enrollment e:enrolledCourses)
		{
			if(e.course_id==Course.course_id)
			{
				throw new DuplicateEnrollmentException();
			}
		}
		Enrollment e = new Enrollment(id,this.student_id,Course.course_id,LocalDate.now());
		e.student.add(this);
		e.course.add(Course);
		enrolledCourses.add(e);
		Course.enrollments.add(e);
		PreparedStatement s = con.prepareStatement("insert into enrollments(enrollment_id,student_id,course_id,enrollment_date) values(?,?,?,?);");
		s.setInt(1,id);
		s.setInt(2, this.student_id);
		s.setInt(3, Course.course_id);
		s.setDate(4, Date.valueOf(LocalDate.now()));
		s.executeUpdate();
		con.commit();
		
	
	}
	
	void updateStudentInfo(int id,String firstName, String lastName, LocalDate dateOfBirth, String email, String phoneNumber) throws InvalidStudentDataException, SQLException
	{
		if(phoneNumber.length()!=10)
		{
			throw new InvalidStudentDataException("Invalid Phone number");
		}
		if(firstName.length()<3)
		{
			throw new InvalidStudentDataException("Invalid First name");
		}
		first_name=firstName;
		last_name=lastName;
		date_of_birth=dateOfBirth;
		this.email=email;
		phone_number=phoneNumber;
		
		PreparedStatement s = con.prepareStatement("update students set first_name=?,last_name=?,date_of_birth=?,emil=?,phone_number=? where student_id=?");
		s.setString(1,first_name);
		s.setString(2,last_name);
		s.setDate(3,Date.valueOf(date_of_birth));
		s.setString(4,email);
		s.setString(5,phone_number);
		s.setInt(6,id);
		s.executeUpdate();
		con.commit();
	}
	
	void makePayment(int id,double amount) throws Exception
	{
		
		Payment p = new Payment(id,this.student_id,amount,LocalDate.now());
		p.payments.add(this);
		payment.add(p);
		PreparedStatement s = con.prepareStatement("insert into payments values(?,?,?,?)");
		s.setInt(1,id);
		s.setInt(2, student_id);
		s.setDouble(3, amount);
		s.setDate(4,Date.valueOf(LocalDate.now()));
		s.executeUpdate();
		con.commit();
	}
	void displayStudentInfo()
	{
		System.out.println("Student ID    : "+student_id);
		System.out.println("First Name    : "+first_name);
		System.out.println("Last Name     : "+last_name);
		System.out.println("Date of Birth : "+date_of_birth);
		System.out.println("Email ID      : "+email);
		System.out.println("Phone Number  : "+phone_number);
	}
	List<Enrollment> getEnrolledCourses()
	{
		return enrolledCourses;
	}
	List<Payment> getPaymentHistory()
	{
		return payment;
	}
}
