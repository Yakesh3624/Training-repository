package entity;

import java.time.LocalDate;

public class lease {
	 private int leaseID;// (Primary Key) 
	 private int vehicleID;// (Foreign Key referencing Vehicle Table)  
	 private int customerID;// (Foreign Key referencing Customer Table) 
	 private LocalDate startDate; 
	 private LocalDate endDate; 
	 private String type; // (to distinguish between DailyLease and MonthlyLease)
	 
	 public lease(int leaseID, int vehicleID, int customerID, LocalDate startDate, LocalDate endDate, String type) {
			super();
			this.leaseID = leaseID;
			this.vehicleID = vehicleID;
			this.customerID = customerID;
			this.startDate = startDate;
			this.endDate = endDate;
			this.type = type;
			
		}
	 
		
		
	 public int getLeaseID() {
		return leaseID;
	}
	public void setLeaseID(int leaseID) {
		this.leaseID = leaseID;
	}
	public int getVehicleID() {
		return vehicleID;
	}
	public void setVehicleID(int vehicleID) {
		this.vehicleID = vehicleID;
	}
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public LocalDate getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	
}
