package entity;

import java.time.LocalDate;

public class Payment {
	 private int paymentID; // (Primary Key) 
	 private int leaseID; //(Foreign Key referencing Lease Table) 
	 private LocalDate paymentDate;
	 private double amount;
	 
	 public Payment(int paymentID, int leaseID, LocalDate paymentDate, double amount) {
			super();
			this.paymentID = paymentID;
			this.leaseID = leaseID;
			this.paymentDate = paymentDate;
			this.amount = amount;
			
		}
	 
	public int getPaymentID() {
		return paymentID;
	}

	public void setPaymentID(int paymentID) {
		this.paymentID = paymentID;
	}

	public int getLeaseID() {
		return leaseID;
	}

	public void setLeaseID(int leaseID) {
		this.leaseID = leaseID;
	}

	public LocalDate getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(LocalDate paymentDate) {
		this.paymentDate = paymentDate;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	

}
