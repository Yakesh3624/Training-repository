package entity;



public class vehicle {
	private int vehicleID; //(Primary Key)
	private String make; 
	private String model;
	private int year; 
	private int dailyRate; 
	private String status; //(available, notAvailable)
	private int passengerCapacity;  
	private double engineCapacity; 
	
	public vehicle(int vehicleID, String make, String model, int year,int dailyRate,String status,int passengerCapacity,double engineCapacity)
	{
		this.vehicleID=vehicleID;
		this.make=make;
		this.model=model;
		this.year=year;
		this.dailyRate=dailyRate;
		this.status=status;
		this.passengerCapacity=passengerCapacity;
		this.engineCapacity=engineCapacity;
		
	}
	
	public vehicle()
	{
		this.vehicleID=0;
		this.make="";
		this.model="";
		this.year=0;
		this.dailyRate=0;
		this.status="notAvailable";
		this.passengerCapacity=4;
		this.engineCapacity=0;
	}

	public int getVehicleID() {
		return vehicleID;
	}

	public void setVehicleID(int vehicleID) {
		this.vehicleID = vehicleID;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getDailyRate() {
		return dailyRate;
	}

	public void setDailyRate(int dailyRate) {
		this.dailyRate = dailyRate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getPassengerCapacity() {
		return passengerCapacity;
	}

	public void setPassengerCapacity(int passengerCapacity) {
		this.passengerCapacity = passengerCapacity;
	}

	public double getEngineCapacity() {
		return engineCapacity;
	}

	public void setEngineCapacity(double engineCapacity) {
		this.engineCapacity = engineCapacity;
	}
	
	

}
