package main;

import java.sql.ResultSet;
import java.time.LocalDate;

import dao.ICarLeaseRepositoryImpl;
import entity.Customer;
import entity.Payment;
//import entity.payment;
import entity.Vehicle;

public class MainModule {
	public static void main(String[] args) throws Exception 
	{
		ICarLeaseRepositoryImpl obj = new ICarLeaseRepositoryImpl();
		
		Vehicle v1 = new Vehicle(1,"Jaguar","XF",2023,140,"notAvailable",4,2);
		Vehicle v2 = new Vehicle(2,"Tesla","Model 3",2021,150,"available",5,0);
		Vehicle v3 = new Vehicle(3,"BMW","M5",2022,160,"available",5,4.4);
		Vehicle v4 = new Vehicle(4,"Bugatti","Chiron",2020,120,"notAvailable",2,8);
		
		Customer c1 = new Customer(1,"David","Wilson","david.wilson@gmail.com","9876054321");
		Customer c2 = new Customer(2,"Emily","Davis","emily.davis@gmail.com","9826407155");
		
		obj.createLease(1,2,1,LocalDate.of(2025, 4, 5),LocalDate.of(2025, 12, 8),"MonthlyLease");
		obj.createLease(2,3,2,LocalDate.of(2024, 5, 1),LocalDate.of(2024, 5, 2),"DailyLease");
		
		
	    Payment p1 = new Payment(1,1,LocalDate.of(2025, 4, 5),0);
		Payment p2 = new Payment(2,2,LocalDate.of(2024, 5, 1),160);
		
		System.out.println("-------------------------Car Management-----------------------------");
		obj.addCar(v1);
		obj.addCar(v2);
		obj.addCar(v3);
		obj.addCar(v4);
		
		obj.removeCar(6);
		
		ResultSet r1 = obj.listAvailableCars();
		while(r1.next())
		{
			System.out.println(r1.getInt(1));
		}
		ResultSet r2 = obj.listRentedCars();
		while(r2.next())
		{
			System.out.println(r2.getInt(1));
		}
		ResultSet r3 = obj.findCarById(1);
		while(r3.next())
		{
			System.out.println(r3.getInt(1));
		}
		System.out.println("-------------------------Customer Management-----------------------------");
		obj.addCustomer(c1);
		obj.addCustomer(c2);
		
		obj.removeCustomer(1);
		
		ResultSet r4 = obj.listCustomers();
		while(r4.next())
		{
			System.out.println(r4.getInt(1));
		}
		
		ResultSet r5 = obj.findCustomerById(1);
		while(r5.next())
		{
			System.out.println(r5.getInt(2));
		}
		System.out.println("-------------------------Lease Management-----------------------------");
		obj.returnCar(2);
		
		ResultSet r6 = obj.listActiveLeases();
		while(r6.next())
		{
			System.out.println(r6.getInt(1));
		}

		ResultSet r7 = obj.listLeaseHistory();
		while(r7.next())
		{
			System.out.println(r7.getInt(1));
		}
		
		System.out.println("-------------------------Payment Management-----------------------------");
		obj.recordPayment(1, 40500);
	}
}
