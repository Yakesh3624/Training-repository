import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import dao.ICarLeaseRepositoryImpl;
import exception.CarNotFoundException;
import exception.CustomerNotFoundException;
import exception.LeaseNotFoundException;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class test { 

	ICarLeaseRepositoryImpl obj;
	
	@BeforeAll
	void setup() throws Exception
	{
		obj = new ICarLeaseRepositoryImpl();
	}
	@AfterAll
	void end()
	{
		obj=null;
	}
	@Test
	void createCar() throws SQLException
	{
//		vehicle v = new vehicle(4,"Bugatti","Chiron",2020,120,"notAvailable",2,8);
//		obj.addCar(v);
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/crs","root","root");
		Statement statement = connection.createStatement();
		ResultSet resultSet = statement.executeQuery("select * from vehicle where vehicleid=4");
		resultSet.next();
		assertEquals(resultSet.getInt(1),4);
		assertEquals(resultSet.getString(2), "Bugatti");
		assertEquals(resultSet.getString(3), "Chiron");
		assertEquals(resultSet.getInt(4),2020);
		assertEquals(resultSet.getInt(5),120);
		assertEquals(resultSet.getString(6), "notAvailable");
		assertEquals(resultSet.getInt(7),2);
		assertEquals(resultSet.getInt(8),8);
	}
	@Test
	void createLease() throws SQLException
	{
		//obj.createLease(2,3,2,LocalDate.of(2024, 5, 1),LocalDate.of(2024, 5, 2),"DailyLease");
		
		
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/crs","root","root");
		Statement statement = connection.createStatement();
		ResultSet resultSet = statement.executeQuery("select * from lease where leaseID=2");
		resultSet.next();
		assertEquals(resultSet.getInt(1),2);
		assertEquals(resultSet.getInt(2), 3);
		assertEquals(resultSet.getInt(3), 2);
		assertEquals(resultSet.getDate(4),Date.valueOf(LocalDate.of(2024, 5, 1)));
		assertEquals(resultSet.getDate(5),Date.valueOf(LocalDate.of(2024, 5, 2)));
		assertEquals(resultSet.getString(6), "DailyLease");
		
	}
	@Test
	void retriveLease() throws Exception
	{
		//obj.returnCar(2);
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/crs","root","root");
		Statement statement = connection.createStatement();
		ResultSet resultSet = statement.executeQuery("select * from lease where leaseID=1");
		assertEquals(resultSet.getFetchSize(),0);
		
	}
	@Test
	void testException()
	{
		assertThrows(CarNotFoundException.class,()->{ 
			obj.removeCar(0);
			});
		assertThrows(CustomerNotFoundException.class,()->{ 
			obj.findCustomerById(0);
			});
		assertThrows(LeaseNotFoundException.class,()->{ 
			obj.returnCar(0);
			});
	}
	

}
