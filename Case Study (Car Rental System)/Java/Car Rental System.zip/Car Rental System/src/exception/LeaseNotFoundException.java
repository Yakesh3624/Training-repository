package exception;

public class LeaseNotFoundException extends Exception {

	public LeaseNotFoundException() {
		super("Lease not found !!!");
	}

}
