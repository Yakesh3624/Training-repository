package util;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	static Connection connection;
	
	public static Connection getConnection() throws SQLException, IOException
	{
		String prop[] =PropertyUtil.getPropertyString().split(" ");
		connection = DriverManager.getConnection(prop[0],prop[1],prop[2]);
		return connection;
	}
	
}
