package util;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertyUtil {
	static String getPropertyString() throws IOException
	{
		FileInputStream file = new FileInputStream("database.properties");
		Properties properties= new Properties();
		properties.load(file);
		
		return properties.getProperty("url")+" "+properties.getProperty("username")+" "+properties.getProperty("password");
	}
	
}
