package dao;

import java.sql.ResultSet;
import java.time.LocalDate;
import entity.Customer;
import entity.Lease;
import entity.Vehicle;

public interface ICarLeaseRepository {
	
	//Car Management
	void addCar(Vehicle car);
	void removeCar(int carID)throws Exception;
	ResultSet listAvailableCars();
	ResultSet listRentedCars();
	ResultSet findCarById(int carID) throws Exception;
	
	//Customer Management 
	void addCustomer(Customer Customer);
	void removeCustomer(int customerID)throws Exception;
	ResultSet listCustomers();
	ResultSet findCustomerById(int customerID) throws Exception;
	
	//Lease Management
	Lease createLease(int leaseID, int customerID, int carID, LocalDate startDate, LocalDate endDate,String type);
	void returnCar( int leaseID ) throws Exception;
	ResultSet listActiveLeases();
	ResultSet listLeaseHistory(); 
	
	//Payment Handling 
	void recordPayment( int leaseID, double amount) throws Exception;
}
