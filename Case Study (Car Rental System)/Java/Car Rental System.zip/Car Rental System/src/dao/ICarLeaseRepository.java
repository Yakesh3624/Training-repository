package dao;

import java.sql.ResultSet;
import java.time.LocalDate;
import entity.customer;
import entity.lease;
import entity.vehicle;

public interface ICarLeaseRepository {
	
	//Car Management
	void addCar(vehicle car);
	void removeCar(int carID)throws Exception;
	ResultSet listAvailableCars();
	ResultSet listRentedCars();
	ResultSet findCarById(int carID) throws Exception;
	
	//Customer Management 
	void addCustomer(customer Customer);
	void removeCustomer(int customerID)throws Exception;
	ResultSet listCustomers();
	ResultSet findCustomerById(int customerID) throws Exception;
	
	//Lease Management
	lease createLease(int leaseID, int customerID, int carID, LocalDate startDate, LocalDate endDate,String type);
	void returnCar( int leaseID ) throws Exception;
	ResultSet listActiveLeases();
	ResultSet listLeaseHistory(); 
	
	//Payment Handling 
	void recordPayment( int leaseID, double amount) throws Exception;
}
