package dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


import entity.Customer;
import entity.Lease;
import entity.Payment;
import entity.Vehicle;
import exception.CarNotFoundException;
import exception.CustomerNotFoundException;
import exception.LeaseNotFoundException;
import util.DBConnection;

public class ICarLeaseRepositoryImpl implements ICarLeaseRepository {
	
	Connection connection;
	PreparedStatement preparedstatement;
	Statement statement;
	
	List<Vehicle> vehicle = new ArrayList<>();
	List<Customer> customer = new ArrayList<>();
	List<Lease> lease = new ArrayList<>();
	List<Payment> payment = new ArrayList<>();
	
	public ICarLeaseRepositoryImpl() throws SQLException, IOException
	{
		connection = DBConnection.getConnection();
	}
	
	@Override
	public void addCar(Vehicle car) {
		try
		{
			preparedstatement = connection.prepareStatement("insert into vehicle values(?,?,?,?,?,?,?,?)");
			preparedstatement.setInt(1, car.getVehicleID());
			preparedstatement.setString(2,car.getMake());
			preparedstatement.setString(3,car.getModel());
			preparedstatement.setInt(4, car.getYear());
			preparedstatement.setInt(5, car.getDailyRate());
			preparedstatement.setString(6,car.getStatus());
			preparedstatement.setInt(7, car.getPassengerCapacity());
			preparedstatement.setDouble(8, car.getEngineCapacity());
			
			preparedstatement.executeUpdate();
			System.out.println("Car added");
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		
	}

	@Override
	public void removeCar(int carID) throws CarNotFoundException, SQLException{
			preparedstatement = connection.prepareStatement("select * from vehicle where vehicleID=?");
			preparedstatement.setInt(1,carID);
			preparedstatement.executeQuery();
			ResultSet resultSet = preparedstatement.getResultSet();
			if(resultSet.getFetchSize()==0)
			{
				throw new CarNotFoundException();
			}
			else {
			preparedstatement = connection.prepareStatement("delete from vehicle where vehicleID=?");
			preparedstatement.setInt(1,carID);
			preparedstatement.executeUpdate();
			
			System.out.println("Car removed");
			}
		
	}

	@Override
	public ResultSet listAvailableCars() {
		ResultSet resultSet = null;
		try {
			statement = connection.createStatement();
			statement.executeQuery("select * from vehicle where status='available'");
			resultSet = statement.getResultSet();
		} catch (SQLException e) {
			System.out.println(e);
		}
		return resultSet;
	}

	@Override
	public ResultSet listRentedCars() {
		ResultSet resultSet = null;
		try {
			statement = connection.createStatement();
			statement.executeQuery("select * from vehicle v inner join lease l on l.vehicleID = v.vehicleID;");
			resultSet = statement.getResultSet();
		} catch (SQLException e) {
			System.out.println(e);
		}
		return resultSet;
	}

	@Override
	public ResultSet findCarById(int carID) throws Exception {
		ResultSet resultSet=null;
			PreparedStatement s =connection.prepareStatement("select * from vehicle where vehicleID=?");
			s.setInt(1, carID);
			s.executeQuery();
			resultSet=s.getResultSet();
			if(resultSet == null)
			{
				throw new CarNotFoundException();
			}
			System.out.println("Car found");
		
		
		return resultSet;
	}

	@Override
	public void addCustomer(Customer customer) {
		try {
		preparedstatement = connection.prepareStatement("insert into customer values(?,?,?,?,?)");
		preparedstatement.setInt(1, customer.getCustomerID());
		preparedstatement.setString(2,customer.getFirstName());
		preparedstatement.setString(3,customer.getLastName());
		preparedstatement.setString(4, customer.getEmail());
		preparedstatement.setString(5, customer.getPhoneNumber());
		
		preparedstatement.executeUpdate();
		System.out.println("Customer added");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

	@Override
	public void removeCustomer(int customerID) throws SQLException, CustomerNotFoundException {
		
			preparedstatement = connection.prepareStatement("select * from customer where customerID=?");
			preparedstatement.setInt(1,customerID);
			preparedstatement.executeQuery();
			ResultSet resultSet = preparedstatement.getResultSet();
			if(resultSet.getFetchSize()==0)
			{
				throw new CustomerNotFoundException();
			}
			else {
			preparedstatement = connection.prepareStatement("delete from customer where customerID=?");
			preparedstatement.setInt(1,customerID);
			preparedstatement.executeUpdate();
			
			System.out.println("Customer removed");
			}
		
	}

	@Override
	public ResultSet listCustomers() {
		ResultSet resultSet = null;
		try {
			statement = connection.createStatement();
			statement.executeQuery("select * from customer");
			resultSet = statement.getResultSet();
		} catch (SQLException e) {
			System.out.println(e);
		}
		return resultSet;
	}

	@Override
	public ResultSet findCustomerById(int customerID) throws CustomerNotFoundException, SQLException {
		ResultSet resultSet=null;
		
			PreparedStatement s =connection.prepareStatement("select * from customer where customerID=?");
			s.setInt(1, customerID);
			s.executeQuery();
			resultSet=s.getResultSet();
			
			if(resultSet.getFetchSize() == 0)
			{
				throw new CustomerNotFoundException();
			}
			System.out.println("Customer found");
		
		return resultSet;
	}

	@Override
	public Lease createLease(int leaseID,int customerID, int carID, LocalDate startDate, LocalDate endDate, String type) {
		try {
			preparedstatement = connection.prepareStatement("insert into lease values(?,?,?,?,?,?)");
			preparedstatement.setInt(1,leaseID);
			preparedstatement.setInt(2,customerID);
			preparedstatement.setInt(3,carID);
			preparedstatement.setDate(4, Date.valueOf(startDate));
			preparedstatement.setDate(5, Date.valueOf(endDate));
			preparedstatement.setString(6, type);
			
			preparedstatement.executeUpdate();
			
			System.out.println("Lease created");
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		Lease l = new Lease(leaseID,customerID,carID,startDate,endDate,type);
		lease.add(l);
		
		return l;
		
		
	}

	@Override
	public void returnCar(int leaseID) throws Exception{
			preparedstatement = connection.prepareStatement("select * from lease where leaseID=?");
			preparedstatement.setInt(1,leaseID);
			preparedstatement.executeQuery();
			ResultSet resultSet = preparedstatement.getResultSet();
			if(resultSet.getFetchSize()==0)
			{
				throw new LeaseNotFoundException();
			}
			else {
			preparedstatement = connection.prepareStatement("delete from lease where leaseID=?");
			preparedstatement.setInt(1,leaseID);
			preparedstatement.executeUpdate();
			System.out.println("Car returned");
			}
			
	}

	@Override
	public ResultSet listActiveLeases() {
		ResultSet resultSet = null;
		try {
			statement = connection.createStatement();
			statement.executeQuery("select * from lease");
			resultSet = statement.getResultSet();
		} catch (SQLException e) {
			System.out.println(e);
		}
		return resultSet;
	}

	@Override
	public ResultSet listLeaseHistory() {
		ResultSet resultSet = null;
		try {
			statement = connection.createStatement();
			statement.executeQuery("select * from lease");
			resultSet = statement.getResultSet();
		} catch (SQLException e) {
			System.out.println(e);
		}
		return resultSet;
	}

	@Override
	public void recordPayment(int leaseID, double amount) throws Exception{
			PreparedStatement s = connection.prepareStatement("update payment set amount=? where leaseID=?");
			s.setDouble(2, amount);
			s.setInt(2, leaseID);
			s.executeUpdate();
			ResultSet resultSet = preparedstatement.getResultSet();
			if(resultSet == null)
			{
				throw new LeaseNotFoundException();
			}
			System.out.println("Payment Recorded");
		
		
		
	}
	
}
