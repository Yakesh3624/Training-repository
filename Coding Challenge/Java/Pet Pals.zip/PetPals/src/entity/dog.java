package entity;

public class dog extends pet{
	private String dogBreed;

	public dog(String name, int age, String breed, String dogBreed) {
		super(name, age, breed);
		this.dogBreed = dogBreed;
	}

	public String getDogBreed() {
		return dogBreed;
	}

	public void setDogBreed(String dogBreed) {
		this.dogBreed = dogBreed;
	}
	

}
