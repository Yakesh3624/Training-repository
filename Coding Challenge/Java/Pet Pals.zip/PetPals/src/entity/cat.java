package entity;

public class cat extends pet{
	private String catColor;

	public cat(String name, int age, String breed, String catColor) {
		super(name, age, breed);
		this.catColor = catColor;
	}

	public String getCatColor() {
		return catColor;
	}

	public void setCatColor(String catColor) {
		this.catColor = catColor;
	}
	
}
