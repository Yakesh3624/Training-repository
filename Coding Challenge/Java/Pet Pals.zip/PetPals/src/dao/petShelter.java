package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import entity.pet;
import exception.NullReferenceException;
import util.MySQLConnection;

public class petShelter{
	private  List<pet> availablePets;
	Connection connection;
	public petShelter() throws Exception {
		availablePets = new ArrayList<>();
		connection = MySQLConnection.getConnection();
	}
	void addPet(pet Pet) throws SQLException
	{
		availablePets.add(Pet);
		PreparedStatement preparedStatement = connection.prepareStatement("insert into pets(name,age,breed,type,availableforadoption) values(?,?,?)");
		preparedStatement.setString(1, Pet.getName());
		preparedStatement.setInt(2, Pet.getAge());
		preparedStatement.setString(3, Pet.getBreed());
		preparedStatement.executeUpdate();
		
		System.out.println("Pet added to the shelter");
	}
	void removePet(pet Pet) throws NullReferenceException, SQLException
	{
		if(availablePets.contains(Pet))
		{
			availablePets.remove(Pet);
			PreparedStatement preparedStatement = connection.prepareStatement("delete from pets where name=?");
			preparedStatement.setString(1, Pet.getName());
			preparedStatement.executeUpdate();
			System.out.println("Pet removed from the shelter");
		}
		else 
		{
			throw new NullReferenceException();
		}
	}
	
	void listAvailablePets() throws SQLException
	{
		Statement statement = connection.createStatement();
		ResultSet resultSet = statement.executeQuery("select * from pets");
		while(resultSet.next())
		{
			System.out.println(resultSet.getString(2));
		}
	}
	

}
