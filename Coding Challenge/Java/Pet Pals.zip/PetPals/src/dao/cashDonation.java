package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

import util.MySQLConnection;

public class cashDonation extends donation{
	private LocalDate donationDate;
	Connection connection;
	public cashDonation(String donorName, double amount, LocalDate donationDate) throws Exception {
		super(donorName, amount);
		this.donationDate = donationDate;
		connection = MySQLConnection.getConnection();
	}
	
	public void recordDonation() throws SQLException
	{
		PreparedStatement preparedStatement = connection.prepareStatement("insert into pets(donorname,donationamount,donationdate) values(?,?,?)");
		preparedStatement.setString(1,getDonorName());
		preparedStatement.setDouble(3,this.getAmount());
		preparedStatement.setDate(4,Date.valueOf(LocalDate.now()));
		preparedStatement.executeUpdate();
	}

}
