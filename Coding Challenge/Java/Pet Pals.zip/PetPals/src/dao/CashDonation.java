package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

import util.MySQLConnection;

public class CashDonation extends Donation{
	private LocalDate donationDate;
	Connection connection;
	public CashDonation(String donorName, double amount, LocalDate donationDate) throws Exception {
		super(donorName, amount);
		this.donationDate = donationDate;
		connection = MySQLConnection.getConnection();
	}
	
	public LocalDate getDonationDate() {
		return donationDate;
	}

	public void setDonationDate(LocalDate donationDate) {
		this.donationDate = donationDate;
	}

	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	public void recordDonation() throws SQLException
	{
		PreparedStatement preparedStatement = connection.prepareStatement("insert into pets(donorname,donationamount,donationdate) values(?,?,?)");
		preparedStatement.setString(1,getDonorName());
		preparedStatement.setDouble(3,this.getAmount());
		preparedStatement.setDate(4,Date.valueOf(donationDate));
		preparedStatement.executeUpdate();
	}

}
