package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import entity.Pet;
import util.MySQLConnection;

public class AdoptionEvent implements IAdoptable{
	Connection connection;
	
	public AdoptionEvent() throws Exception
	{
		connection = MySQLConnection.getConnection();
	}
	public void adopt(int petid,int paticipantid) throws SQLException
	{
		
		PreparedStatement preparedStatement = connection.prepareStatement("insert into adoption(petid,participantid) values(?,?)");
		preparedStatement.setInt(1,petid);
		preparedStatement.setInt(1,paticipantid);
		preparedStatement.executeUpdate();
	}
	void hostEvent(String eventName,LocalDate date, String location,int shelterid) throws SQLException
	{
		PreparedStatement preparedStatement = connection.prepareStatement("insert into adoptionevents(eventname,eventdate,location,shelterid) values(?,?,?,?)");
		preparedStatement.setString(1, eventName);
		preparedStatement.setDate(2, Date.valueOf(date));
		preparedStatement.setString(3, location);
		preparedStatement.setInt(4, shelterid);
		preparedStatement.executeUpdate();
	}
	
	void RegisterParticipant(String participantName,String participantType,int eventid) throws SQLException
	{
		PreparedStatement preparedStatement = connection.prepareStatement("insert into participants(participantname,participanttype,eventid) values(?,?,?)");
		preparedStatement.setString(1, participantName);
		preparedStatement.setString(2, participantType);
		preparedStatement.setInt(3, eventid);
		preparedStatement.executeUpdate();
	}
}
