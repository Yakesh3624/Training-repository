package dao;

import java.sql.SQLException;

import entity.pet;

public interface IAdoptable {
	void adopt(int petid, int participantid) throws SQLException;
}
