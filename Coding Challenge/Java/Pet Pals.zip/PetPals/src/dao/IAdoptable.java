package dao;

import java.sql.SQLException;

import entity.Pet;

public interface IAdoptable {
	void adopt(int petid, int participantid) throws SQLException;
}
