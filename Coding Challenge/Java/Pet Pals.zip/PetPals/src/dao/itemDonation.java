package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

import util.MySQLConnection;

public class itemDonation extends donation{
	private String itemType;
	Connection connection;
	public itemDonation(String donorName, double amount, String itemType) throws Exception {
		super(donorName, amount);
		this.itemType = itemType;
		connection = MySQLConnection.getConnection();

	}
	
	public void recordDonation() throws SQLException
	{
		
		PreparedStatement preparedStatement = connection.prepareStatement("insert into pets(donorname,donationitem,donationdate) values(?,?,?)");
		preparedStatement.setString(1,getDonorName());
		preparedStatement.setString(3,this.itemType);
		preparedStatement.setDate(4,Date.valueOf(LocalDate.now()));
		preparedStatement.executeUpdate();
	}

}
