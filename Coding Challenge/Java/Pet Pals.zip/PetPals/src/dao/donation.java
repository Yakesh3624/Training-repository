package dao;

import java.sql.SQLException;

import exception.InsufficientFundsException;

public abstract class donation {
	private String donorName;
	private double amount;
	
	public donation(String donorName, double amount) throws InsufficientFundsException {
		this.donorName = donorName;
		this.amount = amount;
		if(this.amount<=0)
		{
			throw new InsufficientFundsException();
		}
	}
	
	public String getDonorName() {
		return donorName;
	}

	public void setDonorName(String donorName) {
		this.donorName = donorName;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public abstract void recordDonation() throws SQLException;
	
}
