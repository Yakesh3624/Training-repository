package exception;

public class NullReferenceException extends Exception{

	public NullReferenceException() {
		super("No reference found");
	}
	

}
