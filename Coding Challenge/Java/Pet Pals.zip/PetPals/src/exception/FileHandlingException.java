package exception;

public class FileHandlingException extends Exception{

	public FileHandlingException() {
		super("File can't be read");
	}

}
