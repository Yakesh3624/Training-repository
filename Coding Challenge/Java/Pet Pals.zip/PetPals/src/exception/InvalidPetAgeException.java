package exception;

public class InvalidPetAgeException extends Exception{

	public InvalidPetAgeException() {
		super("Invalid age");
	}
	

}
