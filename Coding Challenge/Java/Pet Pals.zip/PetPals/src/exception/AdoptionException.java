package exception;

public class AdoptionException extends Exception{

	public AdoptionException() {
		super("adoption data not found");
	}

}
