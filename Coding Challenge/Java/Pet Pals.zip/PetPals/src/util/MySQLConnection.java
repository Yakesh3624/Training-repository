package util;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class MySQLConnection {
	public static Connection getConnection() throws Exception
	{
		FileInputStream fileInputStream = new FileInputStream("database.properties");
		Properties p = new Properties();
		p.load(fileInputStream);
		Connection connection = DriverManager.getConnection(p.getProperty("url"),p.getProperty("username"),p.getProperty("password"));
		return connection;
	}
}
